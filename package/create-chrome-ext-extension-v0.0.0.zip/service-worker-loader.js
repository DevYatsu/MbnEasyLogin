import './assets/chunk-3e789fcf.js';
