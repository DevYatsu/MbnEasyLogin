(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-5c07d8ba.js")
    );
  })().catch(console.error);

})();
