import './assets/chunk-394c2fda.js';
