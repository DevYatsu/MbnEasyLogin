console.info("chrome-ext template-svelte-ts content script");
