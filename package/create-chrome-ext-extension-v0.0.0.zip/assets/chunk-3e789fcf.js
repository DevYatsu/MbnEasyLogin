console.info("chrome-ext template-svelte-ts background script");
